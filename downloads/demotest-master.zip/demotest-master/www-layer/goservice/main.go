package main

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"gopkg.in/olahol/melody.v1"
	
)

func main() {

	r := gin.Default()
	
	m := melody.New()

	// curl -X POST 'localhost:5000/flespi?deviceToken=9ebbd0b25760557393a43064a92bae539d962103&deviceName=fake-device-911' -d "{"eventType": "AAS_PORTAL_START", "data": {"uid": "hfe3hf45huf33545", "aid": "1", "vid": "1"}}"
	r.POST("/flespi", func(c *gin.Context) {
		buf := make([]byte, 1024)
		num, _ := c.Request.Body.Read(buf)
		reqBody := string(buf[0:num])
		c.JSON(200, reqBody)
		println("\n[CUSTOM LOG]post /flespi req \n", reqBody)
	})

	r.GET("/", func(c *gin.Context) {
		http.ServeFile(c.Writer, c.Request, "index.html")
	})

	r.GET("/channel/:name", func(c *gin.Context) {
		http.ServeFile(c.Writer, c.Request, "chan.html")
	})

	r.GET("/channel/:name/ws", func(c *gin.Context) {
		m.HandleRequest(c.Writer, c.Request)
	})

	m.HandleMessage(func(s *melody.Session, msg []byte) {
		m.BroadcastFilter(msg, func(q *melody.Session) bool {
			return q.Request.URL.Path == s.Request.URL.Path
		})
	})

	r.GET("/user", func(c *gin.Context) {
		c.String(200,"popos")
	})

	v1user := r.Group("/user")
	{
		v1user.GET("/:name", func(c *gin.Context) {
			name := c.Param("name")
			c.String(http.StatusOK, "Hello %s", name)
		})

		// However, this one will match /user/john/ and also /user/john/send
		// If no other rs match /user/john, it will redirect to /user/john/
		v1user.GET("/:name/*action", func(c *gin.Context) {
			name := c.Param("name")
			action := c.Param("action")
			message := name + " is " + action
			c.String(http.StatusOK, message)
		})
		
		// For each matched request Context will hold the route definition
		v1user.POST("/:name/*action", func(c *gin.Context) {
			test := c.FullPath() == "/user/:name/*action" // true
			fmt.Print(test)
			c.JSON(200, test)
		})
	}

	// r.GET("/flespi", func(c *gin.Context) {
	// 	c.JSON(200, gin.H{
	// 		"deviceName": c.Query("deviceName"),
	// 		"deviceToken": c.Query("deviceToken"),
	// 	})
	// })
	r.Run(":5000")
}